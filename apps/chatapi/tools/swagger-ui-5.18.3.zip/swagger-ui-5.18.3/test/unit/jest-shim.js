import { TextDecoder, TextEncoder } from "node:util"

global.TextDecoder = TextDecoder
global.TextEncoder = TextEncoder
